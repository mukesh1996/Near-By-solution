package com.nbs.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nbs.dao.Dao;
import com.nbs.model.CategoryModel;
import com.nbs.model.EmployeeModel;
import com.nbs.model.RoleModel;
import com.nbs.model.ServiceModel;
import com.nbs.model.cityModel;
import com.nbs.model.componentModel;
import com.nbs.model.privilageModel;
import com.nbs.model.stateModel;

@Repository
public class ServcieImpl implements Service{

	@Autowired
	Dao<RoleModel> daor;
     
	@Autowired
	Dao<privilageModel> daop;
	
	@Autowired
    Dao<stateModel> daos;
    
    @Autowired
    Dao<cityModel> daoc;
    
    @Autowired
    Dao<EmployeeModel> daoe;
    
    @Autowired
    Dao<componentModel> daocomp;
    
    @Autowired
    Dao<CategoryModel> daocat;
    
    @Autowired
    Dao<ServiceModel> daoser;
	
	
	/*Methods for role start here*/
    @Transactional
	public void insertRole(RoleModel r) {
         daor.insert(r);				
	}

    @Transactional
	public List<RoleModel> viewRole(RoleModel r) {
		List<RoleModel> l1 = daor.view(r);
		return l1;
	}
    
    @Transactional
	public RoleModel editRole(long id) {
		RoleModel r = new RoleModel();
    	List<RoleModel> l1 = daor.view(r,id,"roleId");
		r=l1.get(0);
		return r;
	}
    
    @Transactional
	public void updateRole(RoleModel r) {
		daor.update(r);
	}
     
    @Transactional
	public void deleteRole(RoleModel r) {
    	daor.update(r);
		
	}
    
   /* methods for role ends*/
   
    /*methdos for privilege starts*/
    
    @Transactional
	public void insertPrvilege(privilageModel p) {
		
    	daop.insert(p);
		
	}

    @Transactional
	public List<privilageModel> viewPrvilege(privilageModel p) {
		List<privilageModel> l1 = daop.view(p);
		return l1;
	}

	
	@Transactional
	public privilageModel editPrvilege(long id) {
		
		privilageModel p = new privilageModel();
    	List<privilageModel> l1 = daop.view(p,id,"privilageId");
		p=l1.get(0);
		return p;
	}

	@Transactional
	public void updatePrvilege(privilageModel p) {
		daop.update(p);
		
	}
	@Transactional
	public void deletePrvilege(privilageModel p) {
		daop.update(p);
	}
	/* methods for privilege ends*/

	
	 /*methdos for State starts*/
	
	@Transactional
	public void insertState(stateModel s) {
		daos.insert(s);
		
	}
  
	@Transactional
	public List<stateModel> viewState(stateModel s) {
		List<stateModel> l1 = daos.view(s);
		return l1;
	}

	@Transactional
	public stateModel editState(long id){
		stateModel s = new stateModel();
    	List<stateModel> l1 = daos.view(s,id,"stateId");
		s=l1.get(0);
		return s;
	}
	
	@Transactional
	public void updateState(stateModel s) {
		daos.update(s);
	}
      
	@Transactional
	public void deleteState(stateModel s) {
		daos.update(s);
		
	}
	 /*methdos for State Ends*/
	
	/*methdos for City Start*/

	@Transactional
	public void insertCity(cityModel c) {
		
		daoc.insert(c);
		
	}

	@Transactional
	public List<cityModel> viewCity(cityModel c) {
		List<cityModel> l1 = daoc.view(c);
		return l1;
	}

	@Transactional
	public cityModel editCity(long id) {
		cityModel c = new cityModel();
    	List<cityModel> l1 = daoc.view(c,id,"cityId");
		c=l1.get(0);
		return c;
	}

	@Transactional
	public void updateCity(cityModel c) {
		
		daoc.update(c);
		
	}

	@Transactional
	public void deleteCity(cityModel c) {
		daoc.update(c);
		
	}
	
	/*methdos for City Ends*/
	
	/*methdos for Employee Start*/
 
	@Transactional
	public void insertEmp(EmployeeModel e) {
		daoe.insert(e);
		
	}
  
	@Transactional
	public List<EmployeeModel> viewEmp(EmployeeModel e) {
		List<EmployeeModel> l1 = daoe.view(e);
		return l1;
	}
  
	@Transactional
	public EmployeeModel editEmp(long id) {
		EmployeeModel emp= new EmployeeModel();
    	List<EmployeeModel> l1 = daoe.view(emp,id,"employeeId");
    	emp=l1.get(0);
		return emp;
	}

	@Transactional
	public void updateEmp(EmployeeModel e) {
		daoe.update(e);
		
	}

	@Transactional
	public void deleteEmp(EmployeeModel e) {
		 daoe.update(e);
		
	}

	@Transactional
	public List<cityModel> cityViewByState(cityModel c,long id) {
	 System.out.println("at tran");
	 List<cityModel> list = daoc.view(c,id,"state.stateId");
	 System.out.println(list.get(0).getAreaCityName());
	 return list;	
	}

	@Transactional
	public void insertComp(componentModel comp) {
		daocomp.insert(comp);
	}

	@Transactional
	public List<componentModel> viewComp(componentModel comp) {
		List<componentModel> list = daocomp.view(comp);
		return list;
	}

	@Transactional
	public componentModel editComp(long id) {
		componentModel comp = new componentModel();
		List<componentModel> list = daocomp.view(comp,id,"componentId");
		comp = list.get(0);
		return comp;
	}

	@Transactional
	public void updateComp(componentModel comp) {
		daocomp.update(comp);
		
	}

	@Transactional
	public void deleteComp(componentModel comp) {
		daocomp.update(comp);
		
	}

	@Transactional
	public void insertCategory(CategoryModel cat) {
		daocat.insert(cat);
	}

	@Transactional
	public List<CategoryModel> viewCategory(CategoryModel cat) {
		List<CategoryModel> list = daocat.view(cat);
		return list;
	}

	@Transactional
	public CategoryModel editCategory(long id) {
		CategoryModel cat = new CategoryModel();
		List<CategoryModel> list = daocat.view(cat,id,"categoryId");
		cat = list.get(0);
		return cat;
		
	}

	@Transactional
	public void updateCategory(CategoryModel cat) {
		 daocat.update(cat);
	}

	@Transactional
	public void deleteCategory(CategoryModel cat) {
		daocat.update(cat);
		
	}

	  @Transactional
	public void insertService(ServiceModel ser) {
		daoser.insert(ser);
		
	}

	  @Transactional
	public List<ServiceModel> viewService(ServiceModel ser) {
		    
		  List<ServiceModel> list = daoser.view(ser);
			return list;
	}

	  @Transactional
	public ServiceModel editService(long id) {
		     
		   ServiceModel cat = new ServiceModel();
			List<ServiceModel> list = daoser.view(cat,id,"serviceId");
			cat = list.get(0);
			return cat;
	}

	  @Transactional
	public void updateService(ServiceModel ser) {
		  daoser.update(ser);
		
	}

	  @Transactional
	public void deleteService(ServiceModel ser) {
		  daoser.update(ser);
		
	}

	  @Transactional
	public List<ServiceModel> serviceByCategory(ServiceModel s, long id) {
		
		List<ServiceModel> list = daoser.view(s,id,"cat.categoryId"); 
		  
		return list;
	} 
	
	
}
