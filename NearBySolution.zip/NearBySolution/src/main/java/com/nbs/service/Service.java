package com.nbs.service;

import java.util.List;

import com.nbs.model.CategoryModel;
import com.nbs.model.EmployeeModel;
import com.nbs.model.RoleModel;
import com.nbs.model.ServiceModel;
import com.nbs.model.cityModel;
import com.nbs.model.componentModel;
import com.nbs.model.privilageModel;
import com.nbs.model.stateModel;

public interface Service{
	
	public void insertRole(RoleModel r);
	public List<RoleModel> viewRole(RoleModel r);
	public RoleModel editRole(long id);
	public void updateRole(RoleModel r);
	public void deleteRole(RoleModel r);
	
	public void insertPrvilege(privilageModel p);
	public List<privilageModel> viewPrvilege(privilageModel p);
	public privilageModel editPrvilege(long id);
	public void updatePrvilege(privilageModel p);
	public void deletePrvilege(privilageModel p);
	
	
	public void insertState(stateModel s);
	public List<stateModel> viewState(stateModel s);
	public stateModel editState(long id);
	public void updateState(stateModel s);
	public void deleteState(stateModel s);
	
	
	public void insertCity(cityModel c);
	public List<cityModel> viewCity(cityModel c);
	public cityModel editCity(long id);
	public void updateCity(cityModel c);
	public void deleteCity(cityModel c);

	public void insertEmp(EmployeeModel e);
	public List<EmployeeModel> viewEmp(EmployeeModel e);
	public EmployeeModel editEmp(long id);
	public void updateEmp(EmployeeModel e);
	public void deleteEmp(EmployeeModel e);
	
	public List<cityModel> cityViewByState(cityModel c,long id);
	
	
	public void insertComp(componentModel comp);
	public List<componentModel> viewComp(componentModel comp);
	public componentModel editComp(long id);
	public void updateComp(componentModel comp);
	public void deleteComp(componentModel comp);
	
	public void insertCategory(CategoryModel cat);
	public List<CategoryModel> viewCategory(CategoryModel cat);
	public CategoryModel editCategory(long id);
	public void updateCategory(CategoryModel cat);
	public void deleteCategory(CategoryModel cat);
	
	
	public void insertService(ServiceModel ser);
	public List<ServiceModel> viewService(ServiceModel ser);
	public ServiceModel editService(long id);
	public void updateService(ServiceModel ser);
	public void deleteService(ServiceModel ser);
	
	public List<ServiceModel> serviceByCategory(ServiceModel s,long id);
	
	
	
	
}
