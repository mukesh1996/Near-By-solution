package com.nbs.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

@Repository
public class DaoImpl<E> implements Dao<E>{
	
	private SessionFactory sessionFactory;
	
	public DaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
 
	
	public void insert(E e) {
		try{
			Session ses = sessionFactory.getCurrentSession();
			ses.save(e);
		   }catch(Exception e1){
			 
		   }
	}
	public List<E> view(E e) {
		List<E> list1 = null;
		try{
			Session ses = sessionFactory.getCurrentSession();
			String classname = e.getClass().getName();
			Query query = ses.createQuery("from "
					+ classname.substring(classname.lastIndexOf(".") + 1)
					+ " where  active_flag=0");
			list1 = query.list();
		   }catch(Exception e1){
			 
		   }
	  return list1;
	}
	public List<E> view(E e, long id, String name) {
		List<E> list1 = null;
		try{
			Session ses = sessionFactory.getCurrentSession();
			String classname = e.getClass().getName();
			Query query = ses.createQuery("from "
					+ classname.substring(classname.lastIndexOf(".") + 1)
					+ " where  active_flag=0 and "+name+" = '"+id+"' ");
			list1 = query.list();
		   }catch(Exception e1){
			 
		   }
		return list1;
	}


	public void update(E e) {
		try{
			Session ses = sessionFactory.getCurrentSession();
			ses.update(e);
		   }catch(Exception e1){
			 
		   }
		
	}

	
	
}
