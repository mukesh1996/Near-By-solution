package com.nbs.dao;

import java.util.List;

public interface Dao<E> {
    
	public void insert(E e);
	public List<E> view(E e);
	public List<E> view(E e,long id,String name);
	
	public void update(E e);
	
	
}
