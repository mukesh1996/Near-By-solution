package com.nbs.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="web_adminRole")
public class RoleModel {

    @Id
    @GeneratedValue
    @Column(unique=true)
    private long roleId;
    
    private String empRoleName;
    
    
    private String empRoleDesc;
     
    private long created_by_id;	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_by_date", nullable = false)
	private Date created_by_date = new Date();
	private long updated_by_id;
	private Date updated_by_date;
	private long deleted_by_id;
	private Date deleted_by_date;
	@Column(name = "active_flag", nullable = false, columnDefinition = "int default 0")
	private int active_flag;
	
	private String macid;

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getEmpRoleName() {
		return empRoleName;
	}

	public void setEmpRoleName(String empRoleName) {
		this.empRoleName = empRoleName;
	}

	public String getEmpRoleDesc() {
		return empRoleDesc;
	}

	public void setEmpRoleDesc(String empRoleDesc) {
		this.empRoleDesc = empRoleDesc;
	}

	public long getCreated_by_id() {
		return created_by_id;
	}

	public void setCreated_by_id(long created_by_id) {
		this.created_by_id = created_by_id;
	}

	public Date getCreated_by_date() {
		return created_by_date;
	}

	public void setCreated_by_date(Date created_by_date) {
		this.created_by_date = created_by_date;
	}

	public long getUpdated_by_id() {
		return updated_by_id;
	}

	public void setUpdated_by_id(long updated_by_id) {
		this.updated_by_id = updated_by_id;
	}

	public Date getUpdated_by_date() {
		return updated_by_date;
	}

	public void setUpdated_by_date(Date updated_by_date) {
		this.updated_by_date = updated_by_date;
	}

	public long getDeleted_by_id() {
		return deleted_by_id;
	}

	public void setDeleted_by_id(long deleted_by_id) {
		this.deleted_by_id = deleted_by_id;
	}

	public Date getDeleted_by_date() {
		return deleted_by_date;
	}

	public void setDeleted_by_date(Date deleted_by_date) {
		this.deleted_by_date = deleted_by_date;
	}

	public int getActive_flag() {
		return active_flag;
	}

	public void setActive_flag(int active_flag) {
		this.active_flag = active_flag;
	}

	public String getMacid() {
		return macid;
	}

	public void setMacid(String macid) {
		this.macid = macid;
	}
	
	
	
	
    
	
}
