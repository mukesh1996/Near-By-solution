package com.nbs.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name="web_bussinessRegister")
public class BussinessModel {
	
	@Id
	@GeneratedValue
	@Column(unique=true)
	private long bussineesId;
	
	private String bussineesType;
	
	private String bussineesName;
	
	private String bussineesAddress;
	
	private String bussineesDetalis;
	
	@Column(unique=true)
	private String bussineesEmail;
	
	
	private String bussineesPass;
	
	@Column(unique=true)
	private long bussineesMobile;
	
	private String bussineesOwener;
	
	@OneToOne
	@JoinColumn(name="categoryId")
	private CategoryModel cat;
	
	
	
	@OneToOne
	@JoinColumn(name="categoryId")
	private ServiceModel ser;
	
	
	
    private long created_by_id;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_by_date", nullable = false)
	private Date created_by_date = new Date();
	private long updated_by_id;
	
	private Date updated_by_date;
	private long deleted_by_id;
	
	private Date deleted_by_date;
	@Column(name = "active_flag", nullable = false, columnDefinition = "int default 0")
	private int active_flag;
	
	private String macid;
	
	@Column(name = "admin_flag", nullable = false, columnDefinition = "int default 1")
	private int admin_flag;
	
	@Column(name = "user_flag", nullable = false, columnDefinition = "int default 1")
	private int user_flag;
	 
	
	public long getBussineesId() {
		return bussineesId;
	}

	public void setBussineesId(long bussineesId) {
		this.bussineesId = bussineesId;
	}

	public String getBussineesType() {
		return bussineesType;
	}

	public void setBussineesType(String bussineesType) {
		this.bussineesType = bussineesType;
	}

	public String getBussineesName() {
		return bussineesName;
	}

	public void setBussineesName(String bussineesName) {
		this.bussineesName = bussineesName;
	}

	public String getBussineesAddress() {
		return bussineesAddress;
	}

	public void setBussineesAddress(String bussineesAddress) {
		this.bussineesAddress = bussineesAddress;
	}

	public String getBussineesDetalis() {
		return bussineesDetalis;
	}

	public void setBussineesDetalis(String bussineesDetalis) {
		this.bussineesDetalis = bussineesDetalis;
	}

	public String getBussineesEmail() {
		return bussineesEmail;
	}

	public void setBussineesEmail(String bussineesEmail) {
		this.bussineesEmail = bussineesEmail;
	}

	public String getBussineesPass() {
		return bussineesPass;
	}

	public void setBussineesPass(String bussineesPass) {
		this.bussineesPass = bussineesPass;
	}

	public long getBussineesMobile() {
		return bussineesMobile;
	}

	public void setBussineesMobile(long bussineesMobile) {
		this.bussineesMobile = bussineesMobile;
	}

	public String getBussineesOwener() {
		return bussineesOwener;
	}

	public void setBussineesOwener(String bussineesOwener) {
		this.bussineesOwener = bussineesOwener;
	}

	public CategoryModel getCat() {
		return cat;
	}

	public void setCat(CategoryModel cat) {
		this.cat = cat;
	}


	public ServiceModel getSer() {
		return ser;
	}

	public void setSer(ServiceModel ser) {
		this.ser = ser;
	}

	
	public long getCreated_by_id() {
		return created_by_id;
	}

	public void setCreated_by_id(long created_by_id) {
		this.created_by_id = created_by_id;
	}

	public Date getCreated_by_date() {
		return created_by_date;
	}

	public void setCreated_by_date(Date created_by_date) {
		this.created_by_date = created_by_date;
	}

	public long getUpdated_by_id() {
		return updated_by_id;
	}

	public void setUpdated_by_id(long updated_by_id) {
		this.updated_by_id = updated_by_id;
	}

	public Date getUpdated_by_date() {
		return updated_by_date;
	}

	public void setUpdated_by_date(Date updated_by_date) {
		this.updated_by_date = updated_by_date;
	}

	public long getDeleted_by_id() {
		return deleted_by_id;
	}

	public void setDeleted_by_id(long deleted_by_id) {
		this.deleted_by_id = deleted_by_id;
	}

	public Date getDeleted_by_date() {
		return deleted_by_date;
	}

	public void setDeleted_by_date(Date deleted_by_date) {
		this.deleted_by_date = deleted_by_date;
	}

	public int getActive_flag() {
		return active_flag;
	}

	public void setActive_flag(int active_flag) {
		this.active_flag = active_flag;
	}

	public String getMacid() {
		return macid;
	}

	public void setMacid(String macid) {
		this.macid = macid;
	}

	public int getAdmin_flag() {
		return admin_flag;
	}

	public void setAdmin_flag(int admin_flag) {
		this.admin_flag = admin_flag;
	}

	public int getUser_flag() {
		return user_flag;
	}

	public void setUser_flag(int user_flag) {
		this.user_flag = user_flag;
	}

	public BussinessModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	

}
