package com.nbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nbs.model.ServiceModel;
import com.nbs.model.cityModel;
import com.nbs.service.Service;

@Controller

public class ajaxController {
	
	@Autowired
	Service service;
	
	@RequestMapping(value="/cityShow",method=RequestMethod.POST)
	public String cityShow(cityModel c,Model model,@RequestParam("id") long id){
		
		List<cityModel> list1 = service.cityViewByState(c, id); 
		model.addAttribute("list1",list1);
		model.addAttribute("key",1);
        return "ajax";	
	}
	
	@RequestMapping(value="/showService",method=RequestMethod.POST)
	public String showService(ServiceModel s,Model model,@RequestParam("id") long id){
		
		List<ServiceModel> list1 = service.serviceByCategory(s, id); 
		model.addAttribute("list1",list1);
		model.addAttribute("key",2);
        return "ajax";	
	}
 
}
