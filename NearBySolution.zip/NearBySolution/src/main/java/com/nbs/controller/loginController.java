package com.nbs.controller;

import com.nbs.model.BussinessModel;
import com.nbs.model.CategoryModel;
import com.nbs.model.ServiceModel;
import com.nbs.model.stateModel;
import com.nbs.service.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class loginController {

	
	@Autowired
	Service service;
	
	@RequestMapping(value="BussinessLogin")
	public String BussinessLogin(){
		
	    return "FrontEnd/Bussiness/BussinessLogin";
	}
	
	@RequestMapping(value="signupBussiness")
	public ModelAndView signupBussiness(Model m){
		
		CategoryModel c = new CategoryModel();
		List<CategoryModel> listcat= service.viewCategory(c);
		
        stateModel s = new stateModel();
        List<stateModel> listState = service.viewState(s);
		
		m.addAttribute("listcat",listcat);
		m.addAttribute("listState",listState);
	
		
	    return new ModelAndView("FrontEnd/Bussiness/signupBussiness","signBussi",new BussinessModel());
	}
	
	
}
