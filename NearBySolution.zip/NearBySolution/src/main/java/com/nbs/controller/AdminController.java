package com.nbs.controller;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nbs.model.CategoryModel;
import com.nbs.model.RoleModel;
import com.nbs.model.ServiceModel;
import com.nbs.model.cityModel;
import com.nbs.model.componentModel;
import com.nbs.model.privilageModel;
import com.nbs.model.stateModel;
import com.nbs.service.Service;


@Controller
public class AdminController {
	
	  private static String GetMacAddress() throws UnknownHostException,
	    SocketException{
		       String address = null;
		        try {
		        	
		        	InetAddress ip = InetAddress.getLocalHost();
		            NetworkInterface network = NetworkInterface.getByInetAddress(ip);
		            byte[] mac = network.getHardwareAddress();
		           
		            StringBuilder sb = new StringBuilder();
		            for (int i = 0; i < mac.length; i++) {
		            	
		                sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
		                
		            }
		            
		            address = sb.toString();
		           
		        } catch (SocketException e) {

		            e.printStackTrace();

		        }

		       return address;
		   }

  @Autowired
  Service service;
  
    long created_by_id=1; 
    
  
	@RequestMapping(value="/home")
    public String home(){
     return "404";
    }
    
	/*method for role start*/
	
    @RequestMapping(value="/role",method=RequestMethod.GET)
    public ModelAndView role(RoleModel r)
    {
        List<RoleModel> list = service.viewRole(r);
        System.out.println("hello");
        System.out.println(list.get(0).getEmpRoleName());
    	return new ModelAndView("Acm/View/ViewRole","lista",list);
    }
    
    @RequestMapping(value="/AddRole",method=RequestMethod.GET)
    public ModelAndView addRole(){
    	
    	return new ModelAndView("Acm/Add/AddRole","role",new RoleModel());
    }
   
    @RequestMapping(value="InsertRole",method=RequestMethod.POST)
    public String insertRole(@ModelAttribute("role") RoleModel role) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	role.setCreated_by_id(created_by_id);
    	role.setMacid(macid);
    	service.insertRole(role);
    	return "redirect:/role.admin";
    }
    
    @RequestMapping(value="editRole",method=RequestMethod.GET)
       public ModelAndView editRole(@RequestParam("id") long id){
    	
    	RoleModel r =service.editRole(id);
    	
    	System.out.println(r.getEmpRoleName());
    	
    	return new ModelAndView("Acm/Update/UpdateRole","role",r);
    }
    
    @RequestMapping(value="updateRole",method=RequestMethod.POST)
    public String updateRole(@ModelAttribute("role") RoleModel role) throws UnknownHostException, SocketException{	
    	String macid = GetMacAddress();
    	RoleModel r =service.editRole(role.getRoleId());
    	
    	role.setCreated_by_id(r.getCreated_by_id());
    	role.setUpdated_by_id(created_by_id);
    	role.setUpdated_by_date(new Date());
    	role.setMacid(macid);
    	service.updateRole(role);
    	return "redirect:/role.admin";
    }
    
    @RequestMapping(value="deleteRole",method=RequestMethod.GET)
    public String deleteRole(@RequestParam("id") long id,@ModelAttribute("role") RoleModel role){	
    	System.out.println("deleting");
    	role.setRoleId(id);
    	role.setActive_flag(1);
    	role.setDeleted_by_id(created_by_id);
    	role.setDeleted_by_date(new Date());
        System.out.println("Deleting");
    	service.deleteRole(role);
    	return "redirect:/role.admin";
    }
    
    /*method for role Ends*/
    
    /*method for Privilege start*/
    
    @RequestMapping(value="/Prvilege",method=RequestMethod.GET)
    public ModelAndView Prvilege(privilageModel p)
    {
         List<privilageModel> list = service.viewPrvilege(p);
    	return new ModelAndView("Acm/View/ViewPrvilege","listp",list);
    }
    
    @RequestMapping(value="/AddPrivilege",method=RequestMethod.GET)
    public ModelAndView addPrivilege(){
    	
    	return new ModelAndView("Acm/Add/AddPrvilege","AddPrivilege",new privilageModel());
    }
    
    @RequestMapping(value="InsertPrivilege",method=RequestMethod.POST)
    public String insertRole(@ModelAttribute("AddPrivilege") privilageModel pri) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	pri.setCreated_by_id(created_by_id);
    	pri.setMacid(macid);
    	service.insertPrvilege(pri);
    	return "redirect:/Prvilege.admin";
    }
    
    @RequestMapping(value="editPrvilege",method=RequestMethod.GET)
    public ModelAndView editPrvilege(@RequestParam("id") long id){
 	
 	privilageModel p =service.editPrvilege(id);
 	
 	System.out.println(p.getEmpPriviName());
 	
 	return new ModelAndView("Acm/Update/UpdatePrvilege","prvilege",p);
 }
    
    @RequestMapping(value="updatePrivilege",method=RequestMethod.POST)
    public String updatePrivilege(@ModelAttribute("prvilege") privilageModel priv){	
    	priv.setUpdated_by_id(created_by_id);
    	priv.setUpdated_by_date(new Date());
    	service.updatePrvilege(priv);
    	return "redirect:/Prvilege.admin";
    }
    
    @RequestMapping(value="deletePrivilege",method=RequestMethod.GET)
    public String deletePrivilege(@RequestParam("id") long id,@ModelAttribute("prvilege") privilageModel priv){	
    	System.out.println("deleting");
    	priv.setPrivilageId(id);
    	priv.setActive_flag(1);
    	priv.setDeleted_by_id(created_by_id);
    	priv.setDeleted_by_date(new Date());
        System.out.println("Deleting");
    	service.deletePrvilege(priv);;
    	return "redirect:/Prvilege.admin";
    }
    /*method for Privilege Ends*/
    
    /*method for Employee start*/
    
    
   /* @RequestMapping(value="/Employee",method=RequestMethod.GET)
    public ModelAndView Employee(EmployeeModel  emp)
    {
         List<EmployeeModel> list = service.viewEmp(emp);
    	 return new ModelAndView("Acm/View/ViewEmployee","listemp",list);
    }
    
    @RequestMapping(value="/AddEmployee",method=RequestMethod.GET)
    public ModelAndView AddEmployee(Model m){
    	RoleModel r = new RoleModel();
    	List<RoleModel> listrole = service.viewRole(r);
    	
    	stateModel s = new stateModel();
    	List<stateModel> statelist = service.viewState(s);
    	
    	m.addAttribute("listrole",listrole);
    	m.addAttribute("statelist",statelist);
    	return new ModelAndView("Acm/Add/AddEmployee","AddEmployee",new EmployeeModel());
    }
    
    @RequestMapping(value="/InsertEmployee",method=RequestMethod.POST)
    public String InsertEmployee(@ModelAttribute("AddEmployee") EmployeeModel emp,@RequestParam("role") long roleId) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
   
    	RoleModel r = new RoleModel();
    	r.setRoleId(roleId);
    	emp.setRole(r);
     	
    	emp.setCreated_by_id(created_by_id);
    	emp.setMacid(macid);
    	service.insertEmp(emp);
    	return "redirect:/Employee.admin";
    }
    */
    /*method for Employee Ends*/
    
    /*method for State start*/
	
    @RequestMapping(value="/state",method=RequestMethod.GET)
    public ModelAndView State(stateModel s)
    {
         List<stateModel> list = service.viewState(s);
    	 return new ModelAndView("Area/View/ViewState","listp",list);
    }

    @RequestMapping(value="/AddState",method=RequestMethod.GET)
    public ModelAndView addState(){
    	
    	return new ModelAndView("Area/Add/AddState","AddState",new stateModel());
    }
    @RequestMapping(value="InsertState",method=RequestMethod.POST)
    public String insertState(@ModelAttribute("AddState") stateModel state) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	state.setCreated_by_id(created_by_id);
    	state.setMacid(macid);
    	service.insertState(state);
    	return "redirect:/state.admin";
    }
    
    @RequestMapping(value="/editState",method=RequestMethod.GET)
    public ModelAndView editState(@RequestParam("id") long id){
 	
    stateModel s =service.editState(id);
 	
 	System.out.println(s.getAreaStateCode());
 	
 	return new ModelAndView("Area/Update/UpdateState","state",s);
 }
    
    @RequestMapping(value="UpdateState",method=RequestMethod.POST)
    public String updateState(@ModelAttribute("state") stateModel state){	
    	state.setUpdated_by_id(created_by_id);
    	state.setUpdated_by_date(new Date());
    	service.updateState(state);
    	return "redirect:/state.admin";
    }
    
    @RequestMapping(value="deleteState",method=RequestMethod.GET)
    public String deleteState(@RequestParam("id") long id,@ModelAttribute("state") stateModel state){	
    	System.out.println("deleting");
    	state.setStateId(id);
    	state.setActive_flag(1);
    	state.setDeleted_by_id(created_by_id);
    	state.setDeleted_by_date(new Date());
        System.out.println("Deleting");
    	service.deleteState(state);;
    	return "redirect:/state.admin";
    }
    /*method for State Ends*/
    
    
    /*methods for city*/

    @RequestMapping(value="/City",method=RequestMethod.GET)
    public ModelAndView City(cityModel c)
    {
         List<cityModel> list = service.viewCity(c);
    	 return new ModelAndView("Area/View/ViewCity","listp",list);
    }
    @RequestMapping(value="/AddCity",method=RequestMethod.GET)
    public ModelAndView addCity(Model m){
        stateModel s = new stateModel();
    	List<stateModel> liststate=service.viewState(s);
    	m.addAttribute("listState",liststate);
     	return new ModelAndView("Area/Add/AddCity","AddCity",new cityModel());
    }
    @RequestMapping(value="/InsertCity",method=RequestMethod.POST)
    public String insertCity(@ModelAttribute("AddCity") cityModel city,@RequestParam("stateId") long stateId) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	
    	stateModel s = new stateModel();
    	s.setStateId(stateId);
    	city.setState(s);
    	
    	city.setCreated_by_id(created_by_id);
    	city.setMacid(macid);
    	service.insertCity(city);
    	return "redirect:/City.admin";
    }
    
    @RequestMapping(value="/editCity",method=RequestMethod.GET)
    public ModelAndView editCity(@RequestParam("id") long id,Model m){
 	
    cityModel c = service.editCity(id);
    stateModel s = new stateModel();
	List<stateModel> liststate=service.viewState(s);
	m.addAttribute("listState",liststate);
 	System.out.println(c.getAreaCityName());
 	m.addAttribute("state",c);
 	return new ModelAndView("Area/Update/UpdateCity","UpdateCity",c);
  }
    
    @RequestMapping(value="UpdateCity",method=RequestMethod.POST)
    public String UpdateCity(@ModelAttribute("UpdateCity") cityModel city,@RequestParam("stateId") long stateId){	
    	stateModel s = new stateModel();
    	s.setStateId(stateId);
    	city.setState(s);
    	city.setUpdated_by_id(created_by_id);
    	city.setUpdated_by_date(new Date());
    	service.updateCity(city);
    	return "redirect:/City.admin";
    }
    @RequestMapping(value="deleteCity",method=RequestMethod.GET)
    public String deleteCity(@RequestParam("id") long id,@ModelAttribute("UpdateCity") cityModel city){	
    	System.out.println("deleting");
    	city.setCityId(id);
    	city.setActive_flag(1);
    	city.setDeleted_by_id(created_by_id);
    	city.setDeleted_by_date(new Date());
        System.out.println("Deleting");
    	service.deleteCity(city);
    	return "redirect:/City.admin";
    }
    
    /*methods for Ends city*/
    
    /*methods for component Starts*/
    @RequestMapping(value="/Component",method=RequestMethod.GET)
    public ModelAndView Component(componentModel comp)
    {
         List<componentModel> list = service.viewComp(comp);
    	 return new ModelAndView("Acm/View/ViewComponent","listcomp",list);
    }
    @RequestMapping(value="/AddComponent",method=RequestMethod.GET)
    public ModelAndView AddComponent(Model m){
    	
        privilageModel pri = new privilageModel();
    	List<privilageModel> listpri=service.viewPrvilege(pri);
    	
    	m.addAttribute("listpri",listpri);
     	return new ModelAndView("Acm/Add/AddComponent","Command",new componentModel());
    }
    
    @RequestMapping(value="InsertComp",method=RequestMethod.POST)
    public String InsertComp(@RequestParam("PrivilegeId") long PrivilegeId,@RequestParam("empCompName[]") String empCompName[],@RequestParam("empCompLink[]") String empCompLink[],@RequestParam("empCompDesc[]") String empCompDesc[]) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	
    	
    	privilageModel privilage = new privilageModel();
    	privilage.setPrivilageId(PrivilegeId);
	     
	
	    
		for (int i = 0; i < empCompLink.length; i++) {
			
			componentModel cpm = new componentModel(empCompName[i], empCompDesc[i], empCompLink[i], privilage,created_by_id,macid);
			
			service.insertComp(cpm);
			
			
		}
    	
    	return "redirect:/Component.admin";
    }
    
    @RequestMapping(value="editComponent",method=RequestMethod.GET)
    public ModelAndView editComponent(@RequestParam("id") long id,Model m){
 	
 	componentModel comp =service.editComp(id);
 	
 	privilageModel pri = new privilageModel();
	List<privilageModel> listpri=service.viewPrvilege(pri);
	
	m.addAttribute("listpri",listpri);
	m.addAttribute("comp",comp);
 	System.out.println(comp.getEmpCompName());
 	
 	return new ModelAndView("Acm/Update/UpdateComponent","component",comp);
   }
    @RequestMapping(value="UpdateComp",method=RequestMethod.POST)
    public String UpdateComp(@ModelAttribute("component") componentModel comp,@RequestParam("PrivilegeId") long privilageId){	
    	privilageModel priv = new privilageModel();
    	priv.setPrivilageId(privilageId);;
    	comp.setPrivilage(priv);
    	comp.setUpdated_by_id(created_by_id);
    	comp.setUpdated_by_date(new Date());
    	service.updateComp(comp);;
    	return "redirect:/Component.admin";
    }
    
    @RequestMapping(value="deleteComp",method=RequestMethod.GET)
    public String deleteComp(@RequestParam("id") long id,@ModelAttribute("component") componentModel comp){	
    	System.out.println("deleting");
    	comp.setComponentId(id);
    	comp.setActive_flag(1);
    	comp.setDeleted_by_id(created_by_id);
    	comp.setDeleted_by_date(new Date());
        System.out.println("Deleting");
    	service.deleteComp(comp);
    	return "redirect:/Component.admin";
    }
    
    /*methods for Category Starts*/
    @RequestMapping(value="/Category",method=RequestMethod.GET)
    public ModelAndView Category(CategoryModel cat)
    {
         List<CategoryModel> list = service.viewCategory(cat);
    	 return new ModelAndView("Category/View/ViewCategory","listCat",list);
    }
    
    @RequestMapping(value="AddCategory",method=RequestMethod.GET)
    public ModelAndView AddCategory(){
    	
     	return new ModelAndView("Category/Add/AddCategory","category",new CategoryModel());
    }
    
    
    @RequestMapping(value="/InsertCategory",method=RequestMethod.POST)
    public String InsertCategory(@ModelAttribute("category") CategoryModel cat) throws UnknownHostException, SocketException{
    	String macid = GetMacAddress();
    	cat.setCreated_by_id(created_by_id);
    	cat.setMacid(macid);
    	service.insertCategory(cat);
    	return "redirect:/Category.admin";
    }
    
    @RequestMapping(value="editCategory",method=RequestMethod.GET)
    public ModelAndView editCategory(@RequestParam("id") long id){
 	
 	CategoryModel comp =service.editCategory(id);
 	
 	System.out.println();
 	
 	return new ModelAndView("Category/Update/UpdateCategory","Updatecategory",comp);
 }
 
    
 @RequestMapping(value="Updatecategory",method=RequestMethod.POST)
 public String Updatecategory(@ModelAttribute("Updatecategory") CategoryModel cat) throws UnknownHostException, SocketException{	
 	
	String macid = GetMacAddress();
 	CategoryModel r =service.editCategory(cat.getCategoryId());
 	
 	cat.setCreated_by_id(r.getCreated_by_id());
 	cat.setCreated_by_date(r.getCreated_by_date());
 	cat.setUpdated_by_id(created_by_id);
 	cat.setUpdated_by_date(new Date());
 	cat.setMacid(macid);
 	service.updateCategory(cat);
 	return "redirect:/Category.admin";
 }
 
 @RequestMapping(value="deleteCategory",method=RequestMethod.GET)
 public String deleteCategory(@RequestParam("id") long id){	
 	
	System.out.println("deleting");
 
 	CategoryModel c = service.editCategory(id);
	c.setCategoryId(id);
 	c.setActive_flag(1);
 	c.setDeleted_by_id(created_by_id);
 	c.setDeleted_by_date(new Date());
    System.out.println("Deleting");
 	service.deleteCategory(c);;
 	return "redirect:/Category.admin";
 }
 
 /*methods for Service Starts*/
 
 @RequestMapping(value="/Service",method=RequestMethod.GET)
 public ModelAndView Service(ServiceModel ser)
 {
      List<ServiceModel> list = service.viewService(ser);
 	 return new ModelAndView("Category/View/ViewService","listser",list);
 }
 
 @RequestMapping(value="AddService",method=RequestMethod.GET)
 public ModelAndView AddService(Model m){
	 
	  CategoryModel cat = new CategoryModel();
	  List<CategoryModel> list = service.viewCategory(cat);
      m.addAttribute("catList",list); 	
  	return new ModelAndView("Category/Add/AddService","service",new ServiceModel());
 }
 @RequestMapping(value="InsertService",method=RequestMethod.POST)
 public String InsertService(@RequestParam("categoryId") long categoryId,@RequestParam("empSerName[]") String empSerName[],@RequestParam("empserDesc[]") String empserDesc[]) throws UnknownHostException, SocketException{
 	String macid = GetMacAddress();
 	
 	    CategoryModel comp =  new CategoryModel();
 	    comp.setCategoryId(categoryId);
 	  
	    
		for (int i = 0; i < empserDesc.length; i++) {
			
			ServiceModel s = new ServiceModel(comp, empSerName[i], empserDesc[i], created_by_id, macid);
			service.insertService(s);
		}
 	
 	return "redirect:/Service.admin";
 }
 @RequestMapping(value="editService",method=RequestMethod.GET)
 public ModelAndView editService(@RequestParam("id") long id,Model m){
	
	 
	 CategoryModel cat = new CategoryModel();
	 List<CategoryModel> list = service.viewCategory(cat);
     m.addAttribute("catList",list); 
    
	ServiceModel Ser =service.editService(id);
	m.addAttribute("ser",Ser);

	return new ModelAndView("Category/Update/UpdateService","UpdateService",Ser);
}
 @RequestMapping(value="UpdateService",method=RequestMethod.POST)
 public String UpdateService(@ModelAttribute("UpdateService") ServiceModel ser,@RequestParam("categoryId") long categoryId) throws UnknownHostException, SocketException{	
 	
	String macid = GetMacAddress();
 	ServiceModel s =service.editService(ser.getServiceId());
 	
 	CategoryModel c = new CategoryModel();
 	c.setCategoryId(categoryId);
 	
 	ser.setCat(c);
 	ser.setCreated_by_id(s.getCreated_by_id());
 	ser.setCreated_by_date(s.getCreated_by_date());
 	ser.setUpdated_by_id(created_by_id);
 	ser.setUpdated_by_date(new Date());
 	ser.setMacid(macid);
 	service.updateService(ser);;
 	return "redirect:/Service.admin";
 }
 @RequestMapping(value="deleteService",method=RequestMethod.GET)
 public String deleteService(@RequestParam("id") long id){	
 	
	System.out.println("deleting");
 
 	ServiceModel s = service.editService(id);
	s.setServiceId(id);
 	s.setActive_flag(1);
 	s.setDeleted_by_id(created_by_id);
 	s.setDeleted_by_date(new Date());
    System.out.println("Deleting");
 	service.deleteService(s);
 	return "redirect:/Service.admin";
 }

 
}
