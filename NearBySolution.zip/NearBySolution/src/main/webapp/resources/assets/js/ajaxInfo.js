
document.write('<script type="text/javascript" src="jquery-1.10.2.min.js"></script>')



function showP(id)
{
	$.ajax({
		type: "POST",
		url: "ajax",
		data: { id : id , action : 1},
		success: function(html){
			$('#sub').html(html);
			
		}
	});
	
	
}
function showPt(id)
{
	$.ajax({
		type: "POST",
		url: "ajax",
		data: { id : id , action : 2},
		success: function(html){
			$('#subt').html(html);
			
		}
	});

}
function showCity(id)
{
	$.ajax({
		type: "POST",
		url: "ajax",
		data: { id : id , action : 3},
		success: function(html){
			$('#cityemployye').html(html);
			
		}
	});

}

