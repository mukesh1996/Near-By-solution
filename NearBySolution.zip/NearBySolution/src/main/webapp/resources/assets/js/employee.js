


function addcheck()
{
	var ad = document.getElementById("empAddress");
	ad.value=ad.value.trim()
}

function fcheck()
{
var a = document.getElementById("empFname");
a.value=a.value.trim();
if(/[^a-zA-Z\-]/.test(a.value)){
	a.className="form-control parsley-error"
	$("#abc").ready(function(){$.gritter.add({title:"FIRSTNAME",text:"NOT CONTAIN NO OR SPACE INTO NAME",sticky:true})});
	a.focus();
	return false;
}
a.className="form-control parsley-success";
$().ready(function(){$.gritter.removeAll();});
}
function mcheck(){
var a = document.getElementById("empFname");
var b = document.getElementById("empMname");
 if(/[^a-zA-Z\-]/.test(a.value)){
	a.focus();
	return false;
  }
b.value=b.value.trim();
if(/[^a-zA-Z\-]/.test(b.value)){
	b.className="form-control parsley-error"
	$().ready(function(){$.gritter.add({title:"MIDDLENAME",text:"NOT CONTAIN NO OR SPACE INTO NAME",sticky:true})});
	b.focus();
	return false;
}
b.className="form-control parsley-success";
$().ready(function(){$.gritter.removeAll();});
}
function lcheck(){
	var a = document.getElementById("empFname");
	var b = document.getElementById("empMname");
	var c = document.getElementById("empLname");
if(/[^a-zA-Z\-]/.test(a.value)){
		a.focus();
		return false;
}
if(/[^a-zA-Z\-]/.test(b.value)){
	b.focus();
	return false;
  }
c.value=c.value.trim();
c.className="form-control parsley-success";
if(/[^a-zA-Z\-]/.test(c.value)){
	c.className="form-control parsley-error"
	$().ready(function(){$.gritter.add({title:"LASTNAME",text:"NOT CONTAIN NO OR SPACE INTO NAME",sticky:true})});
	c.focus();
	return false;
}
$().ready(function(){$.gritter.removeAll();});
}

function pass()
{
	var p = document.getElementById("empPassword");
	var pr = document.getElementById("REempPassword");
	if(p.value!=pr.value){
		p.className="form-control parsley-error"
		pr.className="form-control parsley-error"
		$().ready(function(){$.gritter.add({title:"PASSWORD",text:"Password Not match",sticky:true})});
		pr.focus();
		return false;
	}
	    p.className="form-control parsley-success"
		pr.className="form-control parsley-success"
	    $().ready(function(){$.gritter.removeAll();});
}

function pin()
{
	var pin = document.getElementById("empPincode");
	pin.value=pin.value.trim();
	if(/[^0-9\-]/.test(pin.value)){
		pin.className="form-control parsley-error"
		$().ready(function(){$.gritter.add({title:"PINCODE",text:"ENTER PROPER PINCODE",sticky:true})});
		pin.focus();
		return false;
	}
	pin.className="form-control parsley-success";
	$().ready(function(){$.gritter.removeAll();});

}

function checkmobile(){
	
	var mob = document.getElementById("empMobile");
	mob.value=mob.value.trim();
	if(/[^0-9\-]/.test(mob.value)){
		mob.className="form-control parsley-error"
		$().ready(function(){$.gritter.add({title:"Mobile",text:"ENTER PROPER Mobile",sticky:true})});
		pin.focus();
		return false;
	}
	mob.className="form-control parsley-success";
	$().ready(function(){$.gritter.removeAll();});

	
	
}
function hide()
{
	document.getElementById("pesonal").style.display="none";
    document.getElementById("Contract").style.display="block";
	
}
function show()
{
	document.getElementById("pesonal").style.display="block";
    document.getElementById("Contract").style.display="none";
	
}
function selectcheck(){
	var z = document.getElementById("role_id");
	if(z.value==0)
	{
	$().ready(function(){$.gritter.add({title:"Role",text:"Role Should Be Selected",sticky:true})});
	return false; 
	}
	$().ready(function(){$.gritter.removeAll();});

}
function email(){	
	
	var email = document.getElementById("empEmail");
	email.value=email.value.trim();
    if(!/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(email.value)){
	email.className="form-control parsley-error"
	$().ready(function(){$.gritter.add({title:"email",text:"ENTER PROPER email",sticky:true})});
	email.focus();
	return false;
}
email.className="form-control parsley-success";
$().ready(function(){$.gritter.removeAll();});

}
function photo()
{
	var photo = document.getElementById("empPhoto");
	if(photo.value==null||photo.value==0)
	{
	$().ready(function(){$.gritter.add({title:"File",text:"Upload Image",sticky:true})});
	return false; 
	}
	$().ready(function(){$.gritter.removeAll();});

}

function doc(){
	
	var doc = document.getElementById("empDocument");
	if(doc.value==null||doc.value==0)
	{
	$().ready(function(){$.gritter.add({title:"File",text:"Upload doc",sticky:true})});
	return false; 
	}
	$().ready(function(){$.gritter.removeAll();});
}

function checke()
{   
	var photo = document.getElementById("empPhoto");
	var doc = document.getElementById("empDocument");
	var a = document.getElementById("empFname");
	var b = document.getElementById("empMname");
	var c = document.getElementById("empLname");
	var e = document.getElementById("empEmail");
	var p = document.getElementById("empPassword");
	var s = document.getElementById("state");
	var s = document.getElementById("cityemployye");
	var z = document.getElementById("role_id");
	var ad = document.getElementById("empAddress");
	var mob = document.getElementById("empMobile");
	
	if(photo.value==null||photo.value==0)
	{
	$().ready(function(){$.gritter.add({title:"File",text:"Upload Image",sticky:true})});
	return false; 
	}

   if(doc.value==null||doc.value==0)
	{
	$().ready(function(){$.gritter.add({title:"File",text:"Upload doc",sticky:true})});
	return false; 
	}
	if(z.value==0)
	{
	$().ready(function(){$.gritter.add({title:"Role",text:"Role Should Be Selected",sticky:true})});
	return false; 
	}
	if(a.value==null||a.value==0)
	{
	a.className="form-control parsley-error";
	a.focus();
	return false; 
	}
	if(b.value==null||b.value==0)
	{
	b.className="form-control parsley-error";
	b.focus();
	return false; 
	}
	if(c.value==null||c.value==0)
	{
	c.className="form-control parsley-error";
	c.focus();
	return false; 
	}
	if(e.value==null||e.value==0)
	{
	e.className="form-control parsley-error";
	e.focus();
	return false; 
	}
	if(p.value==null||p.value==0)
	{
	p.className="form-control parsley-error";
	p.focus();
	return false; 
	}
	if(s.value==0)
	{
	$().ready(function(){$.gritter.add({title:"State",text:"State Should Be Selected",sticky:true})});
	return false; 
	}
	if(c.value==0)
	{
	$().ready(function(){$.gritter.add({title:"City",text:"City Should Be Selected",sticky:true})});
	return false; 
	}
	if(ad.value==null||ad.value==0)
	{
	ad.className="form-control parsley-error";
	ad.focus();
	return false; 
	}
	if(mob.value==null||mob.value==0)
	{
	mob.className="form-control parsley-error";
	mob.focus();
	return false; 
	}
	document.getElementById("pesonal").style.display="none";
    document.getElementById("Contract").style.display="block";
}	


  
function netcheck(){
	
	var empNet = document.getElementById("empNet");
	empNet.value=empNet.value.trim();
	if(/[^0-9.\-]/.test(empNet.value)){
		empNet.className="form-control parsley-error"
		$().ready(function(){$.gritter.add({title:"Mobile",text:"ENTER PROPER Salary",sticky:true})});
		pin.focus();
		return false;
	}
	empNet.className="form-control parsley-success";
}

function calc(){
	
	var empNet = document.getElementById("empNet");
	var empTax = document.getElementById("empTax");
	var empSalary = document.getElementById("empSalary");
	
	empTax.value=empTax.value.trim();
	if(/[^0-9.\-]/.test(empTax.value)){
		empTax.className="form-control parsley-error"
		$().ready(function(){$.gritter.add({title:"Mobile",text:"ENTER PROPER Salary",sticky:true})});
		pin.focus();
		return false;
	}
	empTax.className="form-control parsley-success";
	
	var cal =(empNet.value*empTax.value)/100;
	
	empSalary.value=empNet.value-cal;
}

function upcheck()
{  
	var a = document.getElementById("empFname");
	var b = document.getElementById("empMname");
	var c = document.getElementById("empLname");

	var s = document.getElementById("state");
	var s = document.getElementById("cityemployye");
	var z = document.getElementById("role_id");
	var ad = document.getElementById("empAddress");
	var mob = document.getElementById("empMobile");
	
	
	if(z.value==0)
	{
	$().ready(function(){$.gritter.add({title:"Role",text:"Role Should Be Selected",sticky:true})});
	return false; 
	}
	if(a.value==null||a.value==0)
	{
	a.className="form-control parsley-error";
	a.focus();
	return false; 
	}
	if(b.value==null||b.value==0)
	{
	b.className="form-control parsley-error";
	b.focus();
	return false; 
	}
	if(c.value==null||c.value==0)
	{
	c.className="form-control parsley-error";
	c.focus();
	return false; 
	}
	
	
	if(s.value==0)
	{
	$().ready(function(){$.gritter.add({title:"State",text:"State Should Be Selected",sticky:true})});
	return false; 
	}
	if(c.value==0)
	{
	$().ready(function(){$.gritter.add({title:"City",text:"City Should Be Selected",sticky:true})});
	return false; 
	}
	if(ad.value==null||ad.value==0)
	{
	ad.className="form-control parsley-error";
	ad.focus();
	return false; 
	}
	if(mob.value==null||mob.value==0)
	{
	mob.className="form-control parsley-error";
	mob.focus();
	return false; 
	}
	document.getElementById("pesonal").style.display="none";
    document.getElementById("Contract").style.display="block";
}	